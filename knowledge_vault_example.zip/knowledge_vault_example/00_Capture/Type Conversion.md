---
id: N0028
aliases: ["N0028"]
status: c0-capture
captured: 2026-04-22
source:
triggered_by: "[[Data Types]]"
route:
park_expires:
updated: 2026-04-22
---

# Type Conversion

## Triggered by

[[Data Types]] — spawned from N0024 decomposition on 2026-04-22. Type Conversion content moved verbatim from N0024.

## Raw content

**What is type conversions (casting) in Python?**
*(I think type conversions should be a separate note)*
In Python, there are functions (can you call these functions?) that user can explicitly call to convert a value from one data type to another. 

Note that there is **no implicit conversion across categories**: `1 + "2"` → `TypeError`. Python never auto-converts numbers to strings or vice versa in expressions. Exception to this is conversion of `int` to `float`.

**Example 1:**
```
x = 5       # int
y = 2.0     # float
result = x + y  # result is 7.0, a float
```
In  Example 1, Python promoted the integer `5` to a float before adding, because no information is lost going from `int` to `float`. This happens silently and you don't need to do anything.

Python **never** implicitly converts a string to a number (would be ambiguous).

**Example 2:**
```
age = input("Enter your age: ")   # returns a string, e.g., "25"
age_num = int(age)                # explicit conversion to int
```

Conversion function examples:
```
int("42")      # string → integer: gives 42
str(42)        # integer → string: gives "42"
float(5)       # integer → float: gives 5.0
int(3.9)       # float → integer: gives 3 (truncates, does NOT round)
bool(0)        # integer → boolean: gives False
bool(42)       # integer → boolean: gives True (any non-zero number is True)
```

Data type conversions are used a lot in python programming. A very common scenario — you get input from a user or read data from a file, and it arrives as a string even if it looks like a number.

**Example 3:**

```
age = input("Enter your age: ")  # always returns a string
age + 1                           # error — can't add string + integer
int(age) + 1                      # works — converted string to integer first
```

Note that not every conversion is possible. Python will raise an error if the conversion doesn't make sense.

```
int("hello")   # error — Python can't turn arbitrary text into a number
int("")        # error — empty string isn't a number either
```

## Why I captured this
<!-- One line. If you can't justify in a line, it's probably discard. -->


## Next action
<!-- discard / park until [date] / move to CR / process as atomic / process as map candidate -->