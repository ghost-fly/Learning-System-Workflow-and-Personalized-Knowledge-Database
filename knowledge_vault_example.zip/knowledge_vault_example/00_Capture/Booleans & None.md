---
id: N0027
aliases: ["N0027"]
status: c0-capture
captured: 2026-04-22
source:
triggered_by: "[[Data Types]]"
route:
park_expires:
updated: 2026-04-22
---

# Booleans & None

## Triggered by

[[Data Types]] — spawned from N0024 decomposition on 2026-04-22.

## Raw content
<!-- Whatever you captured — paste, write, link. Messy is fine. -->


## Why I captured this
<!-- One line. If you can't justify in a line, it's probably discard. -->


## Next action
<!-- discard / park until [date] / move to CR / process as atomic / process as map candidate -->