# C0 — Capture Queue

Drop everything here. Articles, quotes, podcast notes, shower thoughts, "I want to learn X" intents.

## The four exits

Every C0 item must exit via one of these:

- **Discard** — delete the file. No guilt.
- **Park** — keep in C0 with `route: park` in frontmatter and a 90-day expiry. If you don't come back to it in 90 days, discard automatically.
- **Reference** — it's a source, quote, or fact. Move to `01_References/`.
- **Process** — it's a seed for a concept. Move to `02_FirstForm/` and apply the protocol.

If you're unsure, park it. Don't let uncertainty clog routing.

## Starting template

`_Templates/C0_capture.md`

## See also

- `_System/00_Overview.md` — full pipeline
- `Example_learn_stats.md` — demo of how a too-large concept decomposes into map + children
