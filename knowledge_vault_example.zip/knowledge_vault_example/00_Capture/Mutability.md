---
id: N0029
aliases: ["N0029"]
status: c0-capture
captured: 2026-04-22
source:
triggered_by: "[[Data Types]]"
route:
park_expires:
updated: 2026-04-22
---

# Mutability

## Triggered by

[[Data Types]] — spawned from N0024 decomposition on 2026-04-22. Mutability content moved verbatim from N0024.

## Raw content

**Mutability**
*(I think mutability should be a separate note)*
Refers to the property of an object whether its contents can be changed or not. In immutable objects, contents cannot be changed. In mutable, contents can be changed after creation.

* Immutable objects: `int`, `float`, `str`, `bool`, `tuple`
* Mutable objects: `list`, `dict`, `set`

**Example 1 (Immutable strings):**
```
# Strings are immutable
name = "John"
name[0] = "A"    # error — you cannot change a character inside a string
```
You can't reach into a string and modify part of it. If you want a different string, you create a whole new one:

```
name = "Aohn"   # this doesn't change the old object — it creates a new one
                  # and points the name at it
```

**Example 2 (Mutable Lists):**
```
# Lists are mutable
colors = ["red", "blue", "green"]
colors[0] = "yellow"   # works fine — list is now ["yellow", "blue", "green"]
```
With a list, you're modifying the _same object_ in place. No new object is created.

**Why mutability matters?**
Because of how names and objects relate — which we discussed earlier. Watch this:

```
# With immutable types — safe, no surprises
a = 10
b = a
a = 15
print(b)   # still 10 — b wasn't affected

# With mutable types — can surprise you
x = [1, 2, 3]
y = x            # y points to the SAME list object
x.append(4)      # modify the list through x
print(y)         # [1, 2, 3, 4] — y sees the change too
```
In the mutable case, `x` and `y` are two names pointing to the **same object**. When you change the object through one name, the change is visible through the other name. This is the single most common source of confusion for beginners working with lists and dictionaries.

**What you need to know now:** just the classification — which types are mutable, which aren't — and the practical consequence that two names pointing to the same mutable object will both see changes. You don't need to go deeper than that yet. The full implications unfold gradually as you write more code and encounter the behavior firsthand.

## Why I captured this
<!-- One line. If you can't justify in a line, it's probably discard. -->


## Next action
<!-- discard / park until [date] / move to CR / process as atomic / process as map candidate -->