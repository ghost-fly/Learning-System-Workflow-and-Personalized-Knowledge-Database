---
id: N0008
aliases: ["N0008"]
status: c0-capture
captured: 2026-04-19
source:
triggered_by: "[[Core Fundamentals]]"
route:
park_expires:
updated: 2026-04-20
---

# Python Syntax Rules

## Triggered by

[[Core Fundamentals]]

## Scope

Beginner-centered reference of core syntax rules for writing legal Python code. Each rule is **prescriptive** — break it and the parser rejects your code before it runs.

For the general concept of what syntax is, and the distinction between syntax (parser-enforced) and convention (linter-flagged), see [[Syntax in Programming languages]].

## Rules

### Rule 1: Indent consistently to group statements into a code block

**Description:** Python uses indentation — not curly braces — to define [[Code & Code Block|code blocks]]. Every line belonging to the same block must be indented by the same amount. Convention: 4 spaces.

**Example:**
```python
if x > 0:
    print("Positive")      # Indented block belongs to `if` header
    x += 1
print("Done")              # Not indented; outside the `if` block
```

**Breaks if:** Inconsistent indentation raises `IndentationError`, or worse, silently misplaces a line out of its intended block — logic breaks without an error message.

**Warning:** Never mix tabs and spaces within the same file.

### Rule 2: End every block-opening header with a colon `:`

**Description:** A [[Code & Code Block|header]] (the line with keyword + condition introducing a block) must end with a colon. The colon tells the parser that an indented block starts next.

**Example:**
```python
if x > 5:              ← header (not part of the block)
    print("something") ← block / suite (this IS the block)
    print("more")      ← still part of the block
```

**Python grammar terms:**
- **Header** — the line with keyword, condition, and colon (`if x > 5:`)
- **Suite** (a.k.a. the block) — the indented lines that follow it
- **Compound statement** — the header + suite together as a unit

**Breaks if:** Missing colon — the parser reads the following lines as independent statements instead of a block → `SyntaxError`.

**Note:** Colons also serve other purposes — see [[Colons in Python|other uses of colon]].

### Rule 3: End each statement with a newline, not a semicolon

**Description:** A newline terminates a statement. Python does not require (or use) semicolons to end statements.

**Example 1:**
```python
x = 5    # statement is ended by a line break
y = 10
```

If you need multiple statements on one line, use semicolons (sparingly):

**Example 2:**
```python
x = 5; y = 10
```

To split a long statement across lines, use a backslash `\` or wrap in brackets. Note: [[Brackets in Python|different types of brackets mean different things]]. The parser implicitly joins lines within brackets.

**Example 3:**
```python
total = 1 + 2 + 3 + \
        4 + 5

# Better: parentheses allow implicit line continuation
total = (1 + 2 + 3 +
         4 + 5)
```

### Rule 4: Prefix single-line comments with `#`

**Description:** Python ignores everything from `#` to the end of the line. Python has no true multi-line comment syntax — use triple-quoted `"""..."""` strings as a pseudo-multi-line comment (they are really unassigned string literals, not true comments).

**Example:**
```python
# This is a comment
x = 5  # Inline comment

"""
This is a multi-line string,
often used as a docstring or pseudo-comment
"""
```

### Rule 5: Follow identifier rules when naming variables

**Description:** Variable names (identifiers) must follow these rules:

- Must start with a letter (a-z, A-Z) or underscore (`_`) — never a digit
- Allowed characters: letters, digits, underscore (no hyphens, spaces, or other punctuation)
- Case-sensitive: `myVar`, `myvar`, and `MYVAR` are three different names
- Cannot use one of Python's 36 reserved keywords as a name: `False`, `None`, `True`, `and`, `as`, `assert`, `async`, `await`, `break`, `class`, `continue`, `def`, `del`, `elif`, `else`, `except`, `finally`, `for`, `from`, `global`, `if`, `import`, `in`, `is`, `lambda`, `nonlocal`, `not`, `or`, `pass`, `raise`, `return`, `try`, `while`, `with`, `yield`

**Example:**
```python
user_name = "Alice"   # Valid
_user_id = 42         # Valid (convention for "internal" variables)
2nd_place = "silver"  # Invalid: starts with a digit
user-name = "Bob"     # Invalid: hyphen not allowed
```

### Rule 6: Assign values with `=`

**Description:** The core idea: `=` means "make the name on the left refer to the value on the right"

**Example:**
```python
x = 10  # Instructs the interpreter to make `x` refer to value `10`
```

This does **not** mean "x equals 10" in the mathematical sense. It means: evaluate the right side, produce a value (10), then attach the label `x` to that value. The right side is always evaluated **first**, before any assignment happens.

This is why something that looks absurd in math works perfectly in Python.

**Example:**
```python
x = 5
x = x + 1  # x is now 6
```

In math, `x = x + 1` is nonsense (no number equals itself plus one). In Python, it means: take the current value of `x` (5), add 1 to get 6, then reassign the label `x` to point to 6. The old value 5 is discarded.

**Multiple assignments — same value:**
```python
a = b = c = 0  # all three names point to 0
```

**Multiple assignments — different values (unpacking):**
```python
x, y = 5, 10   # x gets 5, y gets 10
```
This is called **unpacking**. Python evaluates all the values on the right first, then assigns them left-to-right.

This is why you can swap two variables in one line:
```python
x, y = y, x    # swaps them — no temporary variable needed
```
This works because the entire right side (`y, x`) is evaluated before any assignment happens.

Some languages treat variables as boxes that contain values. Python is different — variables are more like name tags tied to objects with a string. This matters when two names point to the same object, but that's a topic for later. For now, just know that `=` means "point this name at this value," not "put this value into this container."

**What `=` is not:**
- `==` (double equals) tests whether two values are equal — it's a *question*, not a command
- `=` (single equals) performs assignment — it's a *command*, not a question

## Why I captured this

Every valid Python program follows these rules. Breaking them causes syntax errors before code even runs.

## Things that confused me

While working on this note, I stumbled on these concepts that need their own treatment:

* Parser vs. interpreter vs. linter vs. compiler → captured in [[Compiler & Interpreter]]
* Syntax vs. runtime semantics → still open; to be explored

Open questions:
* What is the extent of things I need to learn to fully grasp syntax? Do I need to memorize all the rules?
* Should I keep expanding this note or freeze it at the 6 core rules?

## Related language features (live elsewhere)

These topics surfaced while working on syntax but belong to their own notes:

- Assignment semantics (name tags, evaluation order) → [[Variables]]
- Data type literals (`42`, `'hi'`, `True`, `[]`, `()`, `{}`) → [[Data Types]]
- Function definitions → [[Functions & Modules]]
- Operators (arithmetic, comparison, logical, assignment, identity, membership) → [[Operators]]
- Conditionals and loops → [[Flow Control]]

## Next action
