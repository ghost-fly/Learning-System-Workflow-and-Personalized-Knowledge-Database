---
id: N0017
aliases: ["N0017"]
status: c0-capture
captured: 2026-04-19
source:
triggered_by:
  - "[[Machine Code vs Source Code]]"
  - "[[Syntax in Programming languages]]"
route:
park_expires:
updated: 2026-04-20
domain:
  - Programming
---

# Compiler and Interpreter

## Triggered by

<!-- If this note came up while working on another, wikilink it here. Leave blank for root-level captures. Backlinks will render the trigger chain automatically. -->
[[Machine Code vs Source Code]]
[[Syntax in Programming languages]]

## Raw content
<!-- Whatever you captured — paste, write, link. Messy is fine. -->

What is compiler and interpreter?

Both compilers and interpreters ultimately aim to achieve the same goal: convert human-readable source code into CPU-readable instructions (machine code) so the computer can execute it.

**Compilers** are programs that convert code written in programming languages like C++ (source code) into binary code (machine code) that computers can understand.  If the syntax is incorrect, the code will not compile.

Examples:
C
C++ 

**Interpreters** - I still do not know what this is and how it is different from compilers.



## Why I captured this

<!-- One line. If you can't justify in a line, it's probably discard. -->

I think it is important to understand these two softwares to understand and work well with programming languages. 

## Next action

<!-- discard / park until [date] / move to CR / process as atomic / process as map candidate -->

I am still confused as what is the interpreter and the difference between compiler and interpreter.

What is parsing
What is emulating and emulators?