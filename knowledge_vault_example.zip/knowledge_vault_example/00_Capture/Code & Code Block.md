---
id: N0019
aliases: ["N0019"]
status: c0-capture
captured: 2026-04-20
source:
triggered_by: "[[Python Syntax Rules]]"
route:
park_expires:
updated: 2026-04-20
---

# Code & Code Block

## Triggered by

<!-- If this note came up while working on another, wikilink it here. Leave blank for root-level captures. Backlinks will render the trigger chain automatically. -->
Diving deep into these concepts was trigered while working on [[Python Syntax Rules]]. 

## Raw content

<!-- Whatever you captured — paste, write, link. Messy is fine. -->
**Code** is the most general term. It just means the text instructions you write for a computer to execute. Any line you type in Python that the computer can read and act on is "code." It's the catch-all word — like "writing" in the context of literature.

**Block** (specifically "code block") is where it gets more precise and Python-specific. A block is a _group of lines that belong together_ and execute as a unit. In Python, blocks are defined by **indentation** — the whitespace at the beginning of a line.


```
if temperature > 30:
    print("It's hot")          # This line 
    print("Drink water")       # and this line are indented to signify code block                                 # under `if` header
print("Have a nice day")       # this is not part of the `if` block
```

The two indented lines under the `if` are a **block**. They're grouped together — they _only_ run if the condition (`temperature > 30`) is true. The last line is _not_ part of that block because it's not indented, so it runs regardless.

```
if x > 5:              ← header (not part of the block)
    print("something") ← block / suite (this IS the block)
    print("more")      ← still part of the block
```

According to the Python grammar:
* **Header** — the line with the keyword, condition, and colon (`if x > 5:`)
- **Suite** (a.k.a. the block) — the indented lines that follow it
- **Compound statement** — the header + suite together as a whole unit


This is actually one of Python's distinctive design choices. Most other languages use curly braces `{ }` to mark where a block starts and ends. Python uses indentation instead, which means the visual structure of your code _is_ the logical structure. There's no way to have code that _looks_ grouped but isn't, or vice versa.

**Where blocks show up:** You'll encounter them after any line that ends with a colon (`:`). That includes `if`, `for`, `while`, function definitions (`def`), class definitions, and a few others. The colon is essentially Python saying "a block starts on the next line."

**"Code" vs. "code block"** — the distinction is just scope. All blocks are code, but not all code is a block. "Code" can refer to a single line, an entire file, or your whole project. "Block" specifically means a grouped, indented section that executes together under some controlling statement.

One nuance worth flagging: the term "block" is sometimes used more casually in conversation to mean "a chunk of code" without the precise indentation meaning. Context usually makes it clear which sense someone intends, but the _technical_ meaning in Python is the indentation-defined one.

## Why I captured this
<!-- One line. If you can't justify in a line, it's probably discard. -->

I captured this because I was lacking understanding of the concept and idea behind code and code block. This prevented me from fully grasping indentation concept in [[Python Syntax Rules]].

## Next action

<!-- discard / park until [date] / move to CR / process as atomic / process as map candidate -->
