---
id: N0016
aliases: ["N0016"]
status: c0-capture
captured: 2026-04-19
source:
triggered_by: "[[Python Syntax Rules]]"
route:
park_expires:
updated: 2026-04-20
---

# Syntax in Programming Languages

## Triggered by

[[Python Syntax Rules]]

## Raw content

Syntax in programming is the set of rules defining the correct structure of code statements, including keywords, punctuation, operators, and their arrangement.

It determines whether code is valid and can be parsed by the compiler/interpreter (violations cause syntax errors). If the syntax of a language is not followed, the code will not be understood by the compiler or interpreter.

### Why does syntax exist?

Syntax exists because common rules provide a shared standard and consensus for information communication between programmer and machine. If syntax is violated, the parser displays an error such as `SyntaxError` or `IndentationError` and the code never runs.

### Why do I need to know this?

Knowing the syntax rules of a programming language is crucial to write code correctly and prevent errors before runtime.

### Syntax vs. convention (linter)

It is important to distinguish between **rules of writing (syntax)** and **conventions**:

- **Syntax rules** are enforced by the parser. Break them and the interpreter returns `SyntaxError` or `IndentationError` — the code does not run.
- **Conventions** are style rules (naming, spacing, line length). The interpreter still runs code that violates them.

A **linter** is a separate tool (e.g., `flake8`, `pylint`, `ruff`) that reads code without running it and flags style/convention issues. It checks the code for coding styles or formatting errors.

Code can be syntactically valid but linter-unfriendly. Example: `MyVariable=5` runs fine — parser is happy — but a linter will complain about `snake_case` preference and missing spaces around `=`.

### Syntax in programming vs. syntax in human languages

Compared to human linguistic syntax, linguistic syntax is flexible and meaning-oriented (natural languages tolerate variation). Programming syntax is rigid, formal, and machine-enforced. See [[Syntax in Human Languages]].

## Why I captured this

Understanding what "syntax" means as a general concept — distinct from the list of Python-specific rules — is a prerequisite for working in any programming language.

## Next action

<!-- discard / park until [date] / move to CR / process as atomic / process as map candidate -->