---
id: N0010
aliases: ["N0010"]
status: c0-capture
captured: 2026-04-19
source:
triggered_by: "[[Core Fundamentals]]"
route:
park_expires:
updated: 2026-04-20
---

# Basic Input & Output

## Triggered by

[[Core Fundamentals]]

## Raw content

Spawned from Core Fundamentals map (N0002).

- `print()` — displays output to the console
- `input()` — receives text input from the user, always returns a string

## Why I captured this

The most basic way a Python program communicates with the outside world. Every beginner program uses these.

## Next action