---
id: N0035
aliases: ["N0035"]
status: c0-capture
captured: 2026-04-22
source:
triggered_by: "[[Data Types]]"
route:
park_expires:
updated: 2026-04-22
---

# Literals

## Triggered by

[[Data Types]] — spawned from N0024 decomposition on 2026-04-22. Literals content moved verbatim from N0024.

## Raw content

**What is Literal?**
(Note 1:The following material is taken from LLM answers. I am still very much unclear about Literals.
Note 2: I think this section on Literal should be spawned into a seperate note)
A literal is **the actual value you type directly into your code**. It's the most basic way to create an object — you write the value itself, and Python recognizes what type it is from the syntax.

```
42          # integer literal
3.14        # float literal
"hello"     # string literal
True        # boolean literal
[1, 2, 3]  # list literal
```

Each of these creates an object without you needing to call any function or do any conversion. Python looks at _how you wrote it_ and determines the type automatically.

**How Python tells them apart — it's all in the syntax:**

- Digits with no dot → `int`
- Digits with a dot → `float`
- Wrapped in quotes → `str`
- `True` or `False` → `bool`
- Square brackets → `list`
- Curly braces with key-value pairs → `dict`
- Curly braces without key-value pairs → `set`
- Parentheses with commas → `tuple`

This is why `42` and `"42"` are completely different things. The first has no quotes, so Python sees an integer. The second has quotes, so Python sees a string. Same characters, different literal syntax, different type, different object.

**How this connects to what we've been discussing:**

When I explained type conversion, I used examples like `int("42")`. That's the _explicit_ way to create an integer — calling a function. But when you write just `42` in your code, you're using a literal — the _implicit_ way. The literal is the shortcut. You've been using literals this entire time in every example we've looked at, we just hadn't named the concept.

Think of it this way: you could technically write `int(42)` or `str("hello")`, but that's pointless — the literal already creates the right type directly. Literals are the default, natural way you put data into your code. Explicit conversion is for when you need to _change_ from one type to another.


Question: Is not literal actual value? If it I cannot see why need to come up with a new concept if the "value" explains the same thing

Fair challenge. They're not the same thing, though the difference is subtle.

**A value is what exists in memory — the object itself.** You can't see it directly. It's internal to Python.

**A literal is what you type in your code — the text representation that tells Python to create that value.**

The distinction matters because the same value can come into existence through different means:

```
x = 10          # literal — you typed the value directly
y = 5 + 5       # expression — no literal "10" appears, but the value 10 is produced
z = int("10")   # conversion — again the value 10, but created from a string
```

All three produce the same value (10), but only the first uses a literal. In the other two cases, the value 10 exists but no literal `10` appears anywhere in the code.

Going the other direction — a literal is always text in your source code. Before Python runs the program, `10` is just characters in a file. It becomes a value only when Python reads it and creates the object. So "literal" describes the **source code notation**, while "value" describes the **resulting object in memory**.

**Practically, does this distinction matter much at your stage?** Honestly, not really. In everyday conversation, saying "the value 10" and "the literal 10" are nearly interchangeable and nobody would correct you. The concept becomes more useful later when you need precise language to describe what's happening — for instance, distinguishing between a value your program computed versus one you hardcoded directly into the source. Hardcoded values are literals. Computed values aren't.

So you're right that the concepts overlap heavily. The reason "literal" exists as a separate term isn't to replace "value" — it's to specifically describe **values that appear directly in your source code as written text**, as opposed to values that are produced by computation or conversion.

---

Transferred from [[Python Syntax Rules]] — the literal forms used to write each data type directly in code:

- **Integer:** `42`
- **Float:** `3.14`
- **String:** `'hello'` — use single `'...'` or double `"..."` quotes (no difference)
- **Boolean:** `True` and `False` (capital first letter!)
- **None:** `None` — represents "no value" (equivalent to `null` in other languages)
- **List:** `[1, 2, 3]`
- **Tuple:** `(1, 2, 3)` — immutable
- **Dictionary:** `{"key": "value"}`
- **Set:** `{1, 2, 3}`


## Why I captured this
<!-- One line. If you can't justify in a line, it's probably discard. -->


## Next action
<!-- discard / park until [date] / move to CR / process as atomic / process as map candidate -->