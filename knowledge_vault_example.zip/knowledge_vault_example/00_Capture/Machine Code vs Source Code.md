---
id: N0018
aliases: ["N0018"]
status: c0-capture
captured: 2026-04-19
source:
triggered_by:
route:
park_expires:
updated: 2026-04-20
---

# Machine Code vs Source Code

## Triggered by

<!-- No explicit trigger captured. Add wikilink if you recall what prompted this. -->
[[ ]]

## Raw content
<!-- Whatever you captured — paste, write, link. Messy is fine. -->


What is machine code vs source code?
Machine code is what CPU understands.
Source code is what human writes.


## Why I captured this

<!-- One line. If you can't justify in a line, it's probably discard. -->


## Next action

<!-- discard / park until [date] / move to CR / process as atomic / process as map candidate -->
