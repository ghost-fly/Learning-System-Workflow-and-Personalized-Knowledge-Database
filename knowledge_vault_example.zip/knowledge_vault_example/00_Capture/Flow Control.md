---
id: N0003
aliases: ["N0003"]
status: c0-capture
captured: 2026-04-19
source:
triggered_by: "[[Core Fundamentals]]"
route:
park_expires:
updated: 2026-04-20
---

# Flow Control

## Triggered by

[[Core Fundamentals]]

## Raw content

Spawned from Python Learning map (N0001). Sub-topics identified:

- Conditionals (`if`, `elif`, `else`)
- Loops — `for` loops (iteration) and `while` loops
- Loop Control — `break`, `continue`, `pass`

## Why I captured this

Controls the logic and order of execution in any Python program. Required for writing anything non-trivial.

## Next action

<!-- Try Q1 on "Flow Control" as a whole. May itself be a map — each construct (conditionals, for, while, break/continue) could be atomic. -->
