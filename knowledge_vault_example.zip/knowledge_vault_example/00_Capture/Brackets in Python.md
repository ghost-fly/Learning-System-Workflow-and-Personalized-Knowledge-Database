---
id: N0021
aliases: ["N0021"]
status: c0-capture
captured: 2026-04-20
source:
route:
park_expires:
updated:
---

# Brackets in Python

## Triggered by
<!-- If this note came up while working on another, wikilink it here. Leave blank for root-level captures. Backlinks will render the trigger chain automatically. -->

Exploration if different types of brackets serve different purposes was triggered while learning Rule 3: Statements End at Line Breaks in [[Python Syntax Rules]].
## Raw content
<!-- Whatever you captured — paste, write, link. Messy is fine. -->

>When splitting a long statement across lines, does it matter if round brackets `()`, square brackets `[]`, braces `{}` are used?

Yes and no. The **line continuation** mechanism works identically for all three — Python sees an unclosed bracket and keeps reading the next line. In that sense, no difference.

But the brackets themselves **mean different things**, so you can't just pick one arbitrarily.


```python
# () — parentheses: function calls, tuples, or just grouping
result = (first_value
          + second_value
          + third_value)

# [] — square brackets: lists
colors = ["red",
          "blue",
          "green"]

# {} — curly braces: dictionaries or sets
person = {"name": "John",
          "age": 25}
```

Each bracket type produces a different result. If you swapped `[]` for `{}` in the colors example, you'd get a _set_ instead of a _list_ — those are different data structures with different behaviors. You'll learn the distinctions later, but the point is: the bracket type is dictated by _what you're building_, not by a line-splitting preference.

**The one trick worth knowing:** parentheses `()` can be used _purely for grouping_ with no other side effect, which makes them the go-to when you have a long expression that isn't already inside brackets:

python

```python
# Without parens — syntax error if you just hit enter
total = price * quantity + tax + shipping_fee + handling_fee

# With parens — works fine, and the parens don't change the result
total = (price * quantity
         + tax
         + shipping_fee
         + handling_fee)
```

Here the parentheses aren't creating a tuple or calling a function — they're just telling Python "this expression isn't done yet." `[]` and `{}` can't do this — they'd change your value into a list or set.

So: all three enable line continuation equally, but you use whichever one the context demands, with `()` being the most flexible since it can serve as a "neutral wrapper."

## Why I captured this

<!-- One line. If you can't justify in a line, it's probably discard. -->


## Next action
<!-- discard / park until [date] / move to CR / process as atomic / process as map candidate -->

Probably process it as atomic note?