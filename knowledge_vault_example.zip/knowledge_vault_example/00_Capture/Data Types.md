---
id: N0024
aliases: ["N0024"]
status: c0-capture
type: map
domain: [programming]
coverage: 0/11
captured: 2026-04-21
source:
triggered_by: "[[Core Fundamentals]]"
route:
park_expires:
updated: 2026-04-22
---

# Data Types

## Triggered by

[[Core Fundamentals]]

## Raw content
Split from [[Variables]] (N0009) on 2026-04-21 — Variables content grew substantial and deserved its own focus.

**What is Data?**
For the scope of python programming, **data** = any piece of information a program holds. The number `42`, the text `"hello"`, the answer `True`. That's it. If it's stored in memory, it's data.

**What is Data Type?**
Classification of data that answers two questions about a piece of data:
1. **What values can it hold?** (an `int` holds whole numbers; a `str` holds text)
2. **What operations are valid on it?** (you can divide two integers; you can't divide two strings)

**Why classification is envisioned and embedded in architecture?**
In Python, the type of data tells _[[Compiler & Interpreter |the interpreter]]_ what _kind_ of data an object is, which determines what you can do with it. You can multiply numbers but not text. You can capitalize text but not numbers. The type defines the rules.

**Concrete example of why type matters:**

```
3 + 4        → 7        (int + int = addition)
"3" + "4"    → "34"     (str + str = concatenation)
3 + "4"      → TypeError (int + str = illegal)
```

Same `+` symbol. Different behavior. The _type_ decides what `+` means. This is the core insight: **a type is a contract about behavior, not just a label on a value.**

**Analogy:** A data type is like a passport — it declares what kind of thing you are and what you're allowed to do. _Where it breaks:_ in Python, the passport travels with the _value_, not the _variable_. A variable called `x` can hold an int now and a string five lines later. (This is called _dynamic typing_ — filed for later.)



**Core Types of Data (9):

| Data Type         | Python notation | What it is                                          | Examples                                                                                         | When to use it |
| ----------------- | --------------- | --------------------------------------------------- | ------------------------------------------------------------------------------------------------ | -------------- |
| Integer (Numeric) | `int`           | whole numbers                                       | `5`, `-12`, `1000`                                                                               |                |
| Float (Numeric)   | `float`         | decimal numbers                                     | `3.14`, `-0.5`, `99.0`                                                                           |                |
| String (Text)     | `str`           | plain text                                          | `"hello"`, `"John"`, `"123"` (that last one is text, not a number — the quotes make it a string) |                |
| Boolean           | `bool`          | just two values. Used for decisions and conditions. | `True` or `False`                                                                                |                |
| List              | `list`          | ordered, changeable                                 | `[1, 2, 3]`                                                                                      |                |
| Dictionary        | `dict`          | key-value pairs                                     | {"name": "John", "age": 25}                                                                      |                |
| Tuple             | `tuple`         | ordered, unchangeable:                              | `(1, 2, 3)`                                                                                      |                |
| Set               | `set`           | unordered, no duplicates:                           | `{1, 2, 3}`                                                                                      |                |
| Special one       | ``None``        | represents "nothing" or "no value"                  |                                                                                                  |                |

**What to explicitly NOT worry about yet in Data Types:**
- `complex` numbers (a numeric type for advanced math — you'll likely never use it)
- `frozenset`, `bytes`, `bytearray`, `memoryview` — these exist but are niche
- Deeply memorizing every method on every type. For example, strings have over 40 built-in methods. You don't need to memorize them. Learn the 5–6 most common ones, and know that the others exist so you can look them up when needed.
- Custom types (classes) — you'll eventually learn to create your own data types, but that's a later topic
- How Python implements these internally — interesting eventually, irrelevant now

*Type Conversion content moved to [[Type Conversion]] (N0028) on 2026-04-22.*
*Mutability content moved to [[Mutability]] (N0029) on 2026-04-22.*
*Literals content moved to [[Literals]] (N0035) on 2026-04-22.*

## Decomposition

Atomic types:
- [ ] [[Integers & Floats]] — `#c0-capture`
- [ ] [[Strings]] — `#c0-capture`
- [ ] [[Booleans & None]] — `#c0-capture`

Collection types:
- [ ] [[Lists]] — `#c0-capture`
- [ ] [[Tuples]] — `#c0-capture`
- [ ] [[Dictionaries]] — `#c0-capture`
- [ ] [[Sets]] — `#c0-capture`

Cross-cutting concepts:
- [ ] [[Type Conversion]] — `#c0-capture`
- [ ] [[Mutability]] — `#c0-capture`
- [ ] [[Dynamic Typing]] — `#c0-capture`

Reference:
- [ ] [[Literals]] — `#c0-capture`

## Why I captured this

Every value in Python has a type, and the type determines what operations are valid on it. Knowing the core built-in types and their literal forms is a prerequisite for working with any real data.

## Next action