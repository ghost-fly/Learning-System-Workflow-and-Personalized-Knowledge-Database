---
id: N0005
aliases: ["N0005"]
status: c0-capture
captured: 2026-04-19
source:
triggered_by: "[[Core Fundamentals]]"
route:
park_expires:
updated: 2026-04-20
---

# Functions & Modules

## Triggered by

[[Core Fundamentals]]

## Raw content

Spawned from Python Learning map (N0001). Sub-topics identified:

- Defining functions
- Built-in functions — `len()`, `range()`, `enumerate()`, `zip()`
- Importing — using `import` for standard library modules (math, random, datetime)

## Why I captured this

Functions are the primary unit of reusable code. Modules extend what Python can do without writing from scratch.

## Next action

<!-- Try Q1. "Defining functions" may be atomic. Built-in functions and importing may each be atomic. Assess. -->
