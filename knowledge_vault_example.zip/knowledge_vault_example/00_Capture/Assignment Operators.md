---
id: N0023
aliases: ["N0023"]
status: c0-capture
captured: 2026-04-21
source:
triggered_by: "[[Operators]]"
route:
park_expires:
updated:
---

# Assignment Operators

## Triggered by
<!-- If this note came up while working on another, wikilink it here. Leave blank for root-level captures. Backlinks will render the trigger chain automatically. -->

I spawned this dedicated note from [[Operators]]. 

## Raw content
<!-- Whatever you captured — paste, write, link. Messy is fine. -->

In Python, an [[Operators |assignment operator]], `=`, performs name binding--[[Python Syntax Rules|assigns the value to the name]]. In other words, it says "make the name on the left refer to the value on the right". Assignment operator, `=` does not operate like an equal sign, `=`, operates in math. 

**In math, `=` is a statement of truth.** It asserts that two things are the same — permanently, simultaneously, and in both directions.

`x = 5` means "x _is_ 5." It's a fact about the universe. And it's **bidirectional** — if `x = 5`, then `5 = x` is equally true. You can also read it from either side.

`x = x + 1` is a **contradiction** — no number can equal itself plus one. A mathematician would reject this outright.

**In Python, `=` is a command.** It doesn't describe reality — it **changes** it. It says "from this moment forward, make this name refer to this value."

**Python assignment `=` vs Math equality `=`**

Three key differences:

**1. Direction matters.** Python's `=` is strictly right-to-left. The right side is computed first, then the result is assigned to the left side.

python

```python
x = 5      # valid — assign 5 to x
5 = x      # error — you can't assign to a number
```

In math, both of those are equivalent statements. In Python, the second is meaningless — the left side must be a name that can receive a value.

**2. Time matters.** Math's `=` is timeless — it's always true. Python's `=` happens at a specific moment and can be overwritten.

python

```python
x = 5      # x refers to 5 right now
x = "hello" # x now refers to "hello" — 5 is gone
```

A mathematician would say this is incoherent — x can't be both 5 and "hello." In Python, it just means x changed over time.

**3. `x = x + 1` is perfectly logical.** Read it as a sequence of operations: take the current value of x, add 1, assign the result back to x. It's not an equation — it's an instruction with a before-state and an after-state.

**The closest Python equivalent to math's `=` is actually `==`**, which _asks_ whether two things are equal without changing anything:

python

```python
x == 5   # "is x equal to 5?" — returns True or False
```

So in summary: math's `=` describes what _is_. Python's `=` describes what to _do_.

## Why I captured this

<!-- One line. If you can't justify in a line, it's probably discard. -->


## Next action

<!-- discard / park until [date] / move to CR / process as atomic / process as map candidate -->
