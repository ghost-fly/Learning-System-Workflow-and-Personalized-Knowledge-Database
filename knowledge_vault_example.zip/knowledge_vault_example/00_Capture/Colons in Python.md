---
id: N0020
aliases: ["N0020"]
status: c0-capture
captured: 2026-04-20
source:
triggered_by: "[[Python Syntax Rules]]"
route:
park_expires:
updated: 2026-04-20
---

# Use of the Colons in Python

## Triggered by
<!-- If this note came up while working on another, wikilink it here. Leave blank for root-level captures. Backlinks will render the trigger chain automatically. -->

Looking into the function of colons in Python was triggered during learning Rule 2: Colons Start Blocks in [[Python Syntax Rules]]

## Raw content
<!-- Whatever you captured — paste, write, link. Messy is fine. -->

Colons serve a few distinct roles in Python. Here are 4 roles from most common to least:

**Role 1: Introducing a block**
This is the primary use you'll encounter. The colon signals: "the indented block that follows belongs to this statement."

```
if x > 5:        # starts an if-block
for item in list: # starts a loop block
def greet():      # starts a function body
class Dog:        # starts a class body
```

Without the colon, Python raises a syntax error. It's non-optional — it's part of the grammar, not decoration.

**Role 2: Slicing sequences**
Colons are used inside square brackets to extract portions of a list, string, etc.

```
numbers = [10, 20, 30, 40, 50]
numbers[1:3]   # gives [20, 30] — from index 1 up to (not including) 3
numbers[:2]    # gives [10, 20] — from the start up to index 2
numbers[::2]   # gives [10, 30, 50] — every 2nd item
```

Here the colon means "from ___ to ___" — it's separating a start, stop, and step value.

**Role 3: Dictionary key-value pairs**
Colons separate a key from its value in a dictionary (Python's way of storing labeled data).

```
person = {"name": "John", "age": 25}
```
The colon here means "this key maps to this value."

**Role 4: Type hints (you can ignore this for now)**

```
age: int = 25
def greet(name: str) -> str:
```

This is purely informational — Python doesn't enforce it at runtime. You won't need this for a while, but I mention it so you're not confused if you see it in someone else's code.

That's essentially the complete list. The colon is doing different jobs depending on where it appears, but use #1 — block introduction — is what you'll encounter most as a beginner, and it directly connects to the [[Code & Code Block |block/indentation]] concept from your previous question.


## Why I captured this
<!-- One line. If you can't justify in a line, it's probably discard. -->

I captured different function of the colons because, while learning Rule 2: Colons Start Blocks in [[Python Syntax Rules]], I discovered that the colons can also serve other function besides starting a block. 

## Next action
<!-- discard / park until [date] / move to CR / process as atomic / process as map candidate -->

Probably need to polish, organize and save it as atomic note?