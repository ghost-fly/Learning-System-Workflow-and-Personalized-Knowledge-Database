---
id: N0011
aliases: ["N0011"]
status: c0-capture
captured: 2026-04-19
source:
triggered_by: "[[Core Fundamentals]]"
route:
park_expires:
updated: 2026-04-20
---

# Operators

## Triggered by

[[Core Fundamentals]]

## Raw content

Spawned from Core Fundamentals map (N0002).

- Arithmetic: `+`, `-`, `*`, `/`, `//`, `%`, `**`
- Comparison: `==`, `!=`, `<`, `>`, `<=`, `>=`
- Logical: `and`, `or`, `not`
- Assignment: `=`, `+=`, `-=`, `*=`, `/=`
- Identity: `is`, `is not` — transferred from [[Python Syntax Rules]]
- Membership: `in`, `not in` — transferred from [[Python Syntax Rules]]

## Why I captured this

Operators are the verbs of Python — they define what you can do with values. Required for any logic or calculation.

## Next action
