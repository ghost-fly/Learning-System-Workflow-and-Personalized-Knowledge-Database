---
status: c0-capture
captured: 2026-04-17
source: self
route: process
---

# I want to learn statistics

## Raw content

I want to build real working competence in statistics. Right now I have fragmented knowledge — I recognize terms (mean, variance, p-value, regression) but I can't solve problems end-to-end or reason rigorously about empirical claims involving statistical evidence.

## Why I captured this

Foundational for data analysis, finance modeling, and evaluating empirical claims. Keeps coming up across unrelated projects.

## Next action

Process to C1. Expect Q1 to fail — "statistics" is almost certainly too large to define in one plain sentence without hedging. When it fails, decompose.

---

# Demonstration: how this note moves through the pipeline

*This section is only in the example file. Delete it when you convert to a real note.*

## Step 1: Apply the protocol at the current scale

Invoke **Socratic Interlocutor**. Try to answer the 7 questions for "statistics" as a whole.

**Q1: Define statistics in one plain sentence, no jargon.**

Attempt: *"Statistics is the science of reasoning from data to claims about the world."*

Honest evaluation: this is a gesture, not a definition. It doesn't distinguish statistics from probability theory, data analysis, or machine learning. It doesn't tell you what statistics *does* at the level of concrete operations. **Q1 fails.**

## Step 2: The failure is productive

Because Q1 failed on size rather than understanding, this concept is too large to be atomic. It should become a **map note**.

Applying Q2 (what does it connect / sit between), Q3 (why does it exist, what problem does it solve), and Q5 (what is it easily confused with) at the map level produces a decomposition:

- [ ] [[Descriptive statistics]] — summarizing observed data without inferring beyond it
- [ ] [[Probability theory]] — prerequisite, not statistics proper
- [ ] [[Sampling and the inference problem]] — moving from sample to population
- [ ] [[Hypothesis testing]] (will probably itself be a map)
  - [ ] [[p-value]] — what it actually means vs. what people think it means
  - [ ] [[Type I vs Type II error]]
  - [ ] [[Null hypothesis significance testing — critique and alternatives]]
- [ ] [[Estimation and confidence intervals]]
- [ ] [[Regression and correlation]]
- [ ] [[Bayesian inference]]
- [ ] [[Experimental design]]

Each of these goes **back to C0** as a new capture item. Some (hypothesis testing, probability theory) will themselves fail Q1 and become further maps. Recursion continues until Q1 becomes cleanly answerable.

## Step 3: What this note becomes

This file:
1. Gets renamed to something like `Stats (map).md`
2. Moves to `02_FirstForm/`
3. Gets re-tagged: `status: c1-draft`, `type: map`
4. Uses the `_Templates/C1_map.md` structure
5. Becomes the tracking node for the decomposition

As children atomize and promote, check them off here.

## Step 4: When does the map itself promote?

The map promotes to C2 when:
- Its scope is clearly delineated (you can say what's in and what's out)
- The decomposition is stable — you haven't added or restructured children in weeks
- At least a meaningful fraction of children are themselves in C1 or C2 (you're not shelving an empty scaffold)

A map in C2 is still a live document — `coverage: X/Y` in frontmatter tracks progress, and low coverage on a shelved map triggers lint.

## Step 5: What changes about your learning process

You no longer "learn stats." You learn `[[p-value]]`, then `[[Type I vs Type II error]]`, etc. Each atomic concept passes through the same pipeline as any other note. The map gives you the bird's-eye view of what you've done and what's left.

You will also discover that some sub-concepts you listed in Step 2 don't actually deserve their own notes — they fold into others. Others that you didn't anticipate will appear as you learn. Both are normal. Revise the map when this happens.
