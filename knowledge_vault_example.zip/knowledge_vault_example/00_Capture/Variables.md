---
id: N0009
aliases: ["N0009"]
status: c0-capture
captured: 2026-04-19
source:
triggered_by: "[[Core Fundamentals]]"
route:
park_expires:
updated: 2026-04-21
---

# Variables

## Triggered by

[[Core Fundamentals]]

## Raw content

**What is a variable in the context of Python?**
A variable in Python is a name that points to (or "refers to") a value stored in the computer's memory. A variable is a named reference to an object in memory. It does not contain the value itself — it only points to where the value lives.

Here is the key idea: **In Python, a variable does not "contain" the value inside it.** Instead, it _points to_ the value. This is one of the most fundamental and powerful concepts in Python programming. Once you understand variables as **names that refer to values**, most of Python’s behavior becomes much clearer.

**Analogy**
Think of a variable like a sticky note with a name on it. You write a name on the note (the variable name) and attach it to a box that contains something (the value).

**Example 1:**
```
age = 25          # "age" is the sticky note (variable), 25 is the value in the box
name = "Alice"    # Another sticky note attached to a different box

"""You can later change what’s in the box:"
age = 26          # Now the same sticky note points to a new value"""
```

Example 2:
```
x = 10
```

When you run this, Python does two things:
1. It creates the integer object `10` in memory.
2. It creates the name `x` and attaches it to that object.

If you then write:
```
y = x
```

You are not copying the value `10` into a new box labeled `y`. You are simply putting a second name tag (`y`) on the same object `10`.

Conceptually, variable is bound to the object through assignment operator `=` 

```
y = 5

"""
1. `y` --> is the name (identifier)
2. `=` --> assignment operator: 
3. `5` --> object
"""
```



**What is a name?**
In Python, a **name** (or identifier) is a symbolic label that references an object. It is a string of characters following strict lexical rules (letters, digits, underscores; cannot start with a digit). A name itself has no type, value, or memory footprint. It only functions as a binding target: when you write `x = 5`, `x` becomes a name pointing to the integer object `5`. Names exist within namespaces and are resolved at runtime to locate the actual object they reference.

**What is assignment operator?**
In Python, an [[Assignment Operators|assignment operator]], `=`, performs name binding--[[Python Syntax Rules|assigns the value to the name]]. In other words, it says "make the name on the left refer to the value on the right". Assignment operator, `=` does not operate like an equal sign, `=`, operates in math. 

[[Python Syntax Rules]]



**What is an object?**
An object is any piece of data Python creates and stores in computer's memory. Every value Python works with — every number, every piece of text, every list — is an object.

**Example 1:**
```
x = 10
y = x
```

In Example 1, two things exist here:
- The **object**: `10` — an actual chunk of data sitting somewhere in memory
- The **name**: `x` — a label that points to that object

The object exists independently of the name. The name is just how you refer to it. If you then write:

You don't create a second `10`. You now have two names — `x` and `y` — both pointing to the **same object** in memory.

**Why "object" and not just "value"?**
Because in Python, every piece of data carries more than just its raw value. An object bundles together three things:

- A **type** — what kind of thing it is (integer, string, list, etc.)
- A **value** — the actual data (10, "hello", [1, 2, 3])
- An **identity** — a unique address in memory, so Python can tell two objects apart even if they look the same


**Why does this matter practically?**
Because when you do assignment in Python, you're never copying data — you're pointing a name at an existing object. The object is the thing (it has internal value, type tag associated with it, and unique storage address). The name is just a way to reach it.

**Why name cannot be said to be an object?**
Names cannot be said to be an object because a name doesn't exist as data in memory the way objects do. A name is part of Python's **referencing system**, not a piece of data itself.

**Analogy:**
Think of it this way: a phone book has entries like "Alice → 555-1234." The phone number is a real thing — you can call it, it exists in the phone network. The entry "Alice" in the phone book is just a lookup mechanism to find that number. If you tear the page out of the phone book, the phone number still exists — you just lost your way of finding it.

Names work the same way. They live in a **namespace** — essentially Python's internal lookup table that maps names to objects. The namespace entry `x` isn't data you're working with. It's bookkeeping that Python uses to know what you mean when you type `x`.


**What is namespace?**
A namespace is a lookup table that maps names to objects. That's the whole concept — it's a collection of name-to-object pairings that Python maintains so it knows what each name refers to.


```
"""
Example 1:
"""

x = 10
name = John

"""
Python doesn't just scatter these names randomly into memory. It stores them in a namespace, which you can think of as something like:

x → 10 
name → "John"
"""
```

**Key characteristics:**
- Each namespace is **independent**.
- Namespaces are created at different times and have different **lifetimes**.
- Python uses namespaces to determine which variable you mean when you write a name like `x` or `print`.

**Python has a 3 layers of namespaces:**
- **Built-in namespace** — names that Python provides automatically, available everywhere. Things like `print`, `len`, `type`. You never created these — Python ships with them.
- **Global namespace** — names you create at the top level of your file/program. When you write `x = 10` outside any function, `x` goes into the global namespace.
- **Local namespace** — names created inside a function. They exist only while that function is running, then disappear.


```
"""
Example 2:
"""
x = 10            # goes into global namespace

def greet():
    msg = "hello" # goes into greet's local namespace
    print(msg)

greet()
print(msg)        # error — msg doesn't exist in the global namespace

`msg` lives only in the local namespace of `greet`. The global namespace doesn't know about it, so trying to access it outside the function fails.
```



For the kinds of values (integers, strings, lists, etc.) that variables can point to, see [[Data Types]].

## Why I captured this

Every Python program manipulates data, and variables are how that data is named and reached. Understanding that a variable is a name pointing to an object — not a container — is foundational to everything else in Python.

## Next action
