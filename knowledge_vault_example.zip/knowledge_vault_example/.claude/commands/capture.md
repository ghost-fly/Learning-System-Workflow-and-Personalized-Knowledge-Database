Create a new C0 capture note for: $ARGUMENTS

Follow these steps exactly:

1. Read `index.md` to get the current `next_id` value from the first line.
2. Read today's date from the system.
3. Create a new file in `00_Capture/` named `$ARGUMENTS.md` with this content, substituting the real ID and date:

---
id: [next_id]
status: c0-capture
captured: [YYYY-MM-DD]
source:
route:
park_expires:
updated:
---

# $ARGUMENTS

## Triggered by

<!-- If this note came up while working on another, wikilink it here. Leave blank for root-level captures. Backlinks will render the trigger chain automatically. -->
[[ ]]

## Raw content

<!-- Whatever you captured — paste, write, link. Messy is fine. -->


## Why I captured this

<!-- One line. If you can't justify in a line, it's probably discard. -->


## Next action

<!-- discard / park until [date] / move to CR / process as atomic / process as map candidate -->

4. Increment the `next_id` in `index.md` (e.g. N0012 → N0013). Update only that one line.
5. Report: file created at `00_Capture/$ARGUMENTS.md` with ID [next_id].

Do not add the note to index.md yet — that happens at INGEST when the note is routed and filed.
