# System Overview

The vault is a pipeline with four containers, organized as folders:

```
  C0 (00_Capture)  ────► CR (01_References)   [sideways exit: raw sources]
       │
       ▼
  C1 (02_FirstForm)  ◄──────────┐
       │                        │ revision loop
       │ (promotion gate:       │ when scrutiny
       │  7 questions + stress  │ fails in C2
       │  test where applicable)│
       ▼                        │
  C2 (03_Shelf) ────────────────┘
       │
       ▼
  retrieval + lint
```

## Container rules

### C0 — Capture queue (`00_Capture/`)
Everything starts here: podcast notes, quotes, shower thoughts, "I need to learn X" intents.

Every C0 item exits via one of four paths:
- **Discard** — ephemeral, dead on reflection. Delete the file.
- **Park** — interesting, not now. Stays in C0 with `route: park` and a hard 90-day expiry.
- **Reference** — a quote, stat, or source. Goes to CR.
- **Process** — a seed for a note. Enters C1.

Without strict routing, C0 clogs.

### CR — References (`01_References/`)
Durable library of sources. Not everything you read — only sources you actually used or expect to reuse.

Each entry: citation + stable link + minimal excerpts + one-line "why this matters."

Test: if you can't justify an entry in 12 words, it doesn't belong here.

### C1 — First-Form Notes (`02_FirstForm/`)
Drafts. Where formation happens. Two shapes:

- **Atomic draft** — concept-sized, being refined toward promotion
- **Map draft** — a concept too large to atomize. Decomposes into sub-concepts that go back to C0 as new items.

### C2 — Shelf (`03_Shelf/`)
Solid, linked, promoted knowledge. Passed the 7-question gate (and stress test for applicable types). Also holds map notes that organize atomic children.

Admission is earned, not timed.

## The recursion

A learning intent ("learn stats") enters C0. When processed, the protocol fails at that scale — you can't define stats in one sentence without hedging. The failure is productive: it decomposes "stats" into sub-topics. Those sub-topics go back to C0 as new items. The original "stats" note becomes a **map** in C1 (eventually C2), tracking what's been atomized and where.

**Stopping rule:** stop decomposing when Q1 (define in one sentence, no jargon, no hedging) becomes genuinely answerable. That's atomic granularity.

You will miscalibrate at first. Too-large notes bounce back to C0 as more items. The cost of recalibration is low.

## Lifecycle of a single note

1. **Capture** in C0 with minimal metadata (use `_Templates/C0_capture.md`)
2. **Route** — decide exit (discard / park / reference / process)
3. **Promote to C1** — move file to `02_FirstForm/`. Update status tag.
4. **Form** — apply protocol with **Socratic Interlocutor**. Iterate as needed.
5. **Gate** — run **Devil's Advocate** against the 7 questions + stress test (if applicable)
6. **Promote to C2** — move file to `03_Shelf/`. **Librarian** updates links and tags.
7. **Live** — note participates in the graph; surfaces via neighborhood reactivation
8. **Maintain** — weekly surface (5 min) + monthly lint (10–15 min) prevent rot

## The four characters

Each LLM role has a narrow posture. Do not blend them.

- **Socratic Interlocutor** — formation, prerequisite probing, gap-finding
- **Devil's Advocate** — promotion-gate scrutiny, edge cases, falsification
- **Librarian** — tagging, linking, organizing (unified grunt work)
- **Lint Auditor** — periodic sweeps for orphans, staleness, coverage

See `03_Characters.md` for invocation prompts.

## What to read next

- `01_Protocol.md` — the 7 questions, in detail
- `02_Taxonomy.md` — the tag system
- `03_Characters.md` — how to invoke each LLM role
- `04_Retrieval.md` — the three review mechanisms
- `05_Lint.md` — what maintenance actually looks like
