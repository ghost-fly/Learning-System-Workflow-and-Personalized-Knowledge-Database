# Inquiry Questions

Reference set for interrogating sources and filtering information during learning. The pre-capture stage — before a C0 note exists.

## Distinction from the 7-question protocol

| | Protocol (`01_Protocol.md`) | Inquiry (this file) |
|---|---|---|
| Target | Your own understanding | External sources + your starting state |
| Stage | C1 formation, C1→C2 gate | Pre-capture, while learning |
| Purpose | Validate what you know | Filter signal from noise |

## Core principle

**Don't aim to answer all questions.** Answer the minimum set that gives you a stable mental hook. Expand only as far as your immediate goal demands — solving problems, passing an exam, teaching, applying, researching. Question-bloat defeats the purpose.

---

## Phase 1 — Framing (before engaging any source)

Three questions to answer *before* you open a book, watch a video, or talk to an LLM. These set the scope and activate what you already know.

### 1.1. What will I be able to DO after learning this?
Pass a standard exam? Apply the method to real data? Teach or explain to others? Critique the methodology? The answer determines depth. "Pass an exam" and "research the methodology" require fundamentally different treatments.

### 1.2. What's my naive map?
Before touching any source, spend a few minutes writing down everything you *think* you need to answer. This activates tangential knowledge you already have and creates a concrete artifact of your starting ignorance — valuable later when measuring progress.

### 1.3. What prerequisites does this rest on — and am I solid on them?
List what you need to already understand. Then honestly assess which prerequisites you're shaky on. Most learning failures are actually prerequisite failures — pattern-matching vocabulary without grasping foundations creates the illusion of understanding.

---

## Phase 2 — Core Interrogation (the minimum stable-hook set)

Five questions that together give most concepts a stable place in your mind. Start here.

### 2.1. What kind of thing is this?
Principle, process, framework, tool, mental model, law, heuristic, distinction? Most people skip this. Knowing that "opportunity cost" is a *mental model* while "comparative advantage" is a *principle derived from a proof* changes how you study each.

### 2.2. What problem does it solve?
Every concept was invented or discovered because something needed explaining or solving. What problem, question, or confusion does this exist to address? If you can't answer this, you don't yet understand why the concept matters — and unmotivated knowledge doesn't stick.

### 2.3. What's the minimal concrete example?
If the explainer can't produce a worked case, they don't understand it either. Demand one. Abstract without concrete = vibes.

### 2.4. What is this NOT — and what is it easily confused with?
The most dangerous failure mode isn't ignorance, it's false equivalence. Tagging what a concept is *not* is often more useful than what it is.

### 2.5. What is this most similar to that I already know?
Force yourself to answer *before* asking an LLM. Your answer reveals your current mental map. Even a wrong analogy is useful — when corrected, the contrast strengthens encoding.

---

## Phase 3 — Extensions (deeper engagement)

Pull these in when your goal demands more than a stable hook.

### 3.1. What did people do or think before this existed?
Forces historical/intellectual context. Reveals what the concept *replaced* or *improved upon* — a richer tag than any category label.

### 3.2. How was this developed historically?
The chain of ideas and people that produced the current form. Often explains why the framing is what it is.

### 3.3. What is the mathematical or logical justification?
Required for formulas and methods. Optional for most other things.

### 3.4. Where does this sit on the abstraction ladder?
Is it a specific instance of something more general? A general principle with specific instances you might already know? Placing it on the ladder connects knowledge vertically.

### 3.5. Where does it break?
Edge cases, failure modes, when it doesn't apply. Sources that only show the upside are selling, not teaching.

### 3.6. Who disagrees, and what's their strongest argument?
Steelman the opposition. If you can't find a critic, you're in an echo chamber.

### 3.7. What are the open questions or extensions?
Where is this concept still evolving? What's unresolved? Shows the live edge of the field.

### 3.8. Can I actually apply it without the source in front of me?
The final test. If you can't reproduce the concept unaided, you don't own it yet — you're renting it from the source.

---

## Signal Rule

One source that cleanly addresses 5+ questions from Phase 2 is more valuable than ten that address 1–2. Most "information gibberish" fails 2.2, 2.3, and 2.4.

---

## Extensions

<!-- Add more questions here as they emerge. Propose which phase they belong to. -->
