# The Protocol

Seven questions. Applied at any scale. Output shape (atomic note vs map note) emerges from what passes and what doesn't.

## The seven questions

1. **Define it in one plain sentence, no jargon.**
   Do you own the meaning, or are you renting it from a textbook?

2. **What does it connect or sit between?**
   Relational understanding. Which concepts does it link? What distinction does it mark?

3. **Why does it exist? What problem does it solve?**
   Unmotivated knowledge doesn't stick. If you can't answer, you don't know why it matters.

4. **What breaks at extremes or edge cases?**
   Boundary knowledge. Where does the concept fail? When does it not apply?

5. **What is it easily confused with, and how do you distinguish them?**
   False equivalence is the worst failure mode. What a concept *isn't* is often more useful than what it is.

6. **Where have you used it, or where would you use it?**
   Hard gate. If you can't name a real or concrete hypothetical application, the concept isn't ready for C2.

7. **What's your current confidence, and what would change your mind?**
   Epistemic honesty plus falsifiability. Label uncertainty explicitly.

## Stress test (for applicable types)

For type `#formula` and `#method`, a passed stress test is required for C2 promotion:
- At least one worked example from scratch
- At least one problem where you applied it and verified the result against a trusted source
- At least one case where you recognize when NOT to use it

For types `#concept`, `#principle`, `#distinction`, `#heuristic`, `#fact`, `#map`: stress test is optional but encouraged where applicable.

## Reading the output

| Result | Meaning | Action |
|---|---|---|
| All 7 clean | Atomic note, ready for C2 | Promote after Devil's Advocate sweep |
| Q1 fails (can't define in one sentence without hedging) | Concept is too large | Produce map note; spawn children back to C0 |
| Q6 fails (no application) | Not ready | Either apply it or demote to CR |
| Q4 or Q5 fail | Center understood, boundaries not | Stay in C1, dig further |
| Q7 reveals high uncertainty | Possibly contested | Tag `#contested`, keep in C1, or promote with explicit caveat |

## When to invoke

- **C0 → C1:** run the full protocol. Output shape (atomic vs map) determines the template.
- **C1 → C2:** run the protocol again, with Devil's Advocate applied to each answer.
- **C2 revisit** (lint-flagged or neighborhood-surfaced): spot-check Q1, Q6, Q7.

## Guidance, not ritual

The protocol is an instrument, not a liturgy. If a question doesn't apply to a particular note (e.g., "why does it exist" for a raw historical fact), skip it and note why in the draft. The goal is the property each question tests, not the question itself.

## Granularity calibration

You will, early on, push concepts to C1 that should have been maps, and propose maps that should have been atomic. The protocol itself is the recalibration instrument — if Q1 fails after you thought it was atomic, decompose. If all 7 pass easily on what you thought was a map, maybe it's actually atomic and you were intimidated by the domain.

Expect miscalibration for the first 20–30 notes. After that, your intuition for "what's an atomic concept" stabilizes.
