# Lint Operations

What to check, and what to do about each. Lint Auditor reports; you decide.

## The checks

### Orphan detection
Notes with zero incoming AND outgoing wikilinks.

**Interpretation:** Either the note isn't actually part of your thinking (nothing connects to it) or you haven't done the connective work yet.

**Action options:**
- Find 1–2 notes it should link to and add the links
- Demote to CR if it's really just a fact or quote, not a concept
- Archive if it was a false start

---

### Staleness
Notes with `updated:` older than 3 months AND status `#c2-solid`.

**Interpretation:** Either the note is timelessly correct and you haven't needed to touch it (fine) or you've silently forgotten what's in it (not fine).

**Action options:**
- Title-only recognition test — if you can summarize from the title in one sentence, it's still alive. Touch `updated:` and move on.
- If you can't, tag `#needs-revision` and schedule actual revisit.
- If the note is about a domain you've moved on from, consider archiving.

---

### Map coverage
Map notes where < 50% of listed children are in the shelf (`#c2-solid`).

**Interpretation:** Either this is an in-progress learning area (normal) or an abandoned one (signal).

**Action options:**
- Actively growing → leave it. Low coverage is expected early.
- Abandoned → archive the map. Optionally note why.
- Map structure was wrong → refactor. The children you *did* promote might reveal a better way to carve the domain.

---

### Confidence drift
Notes with `confidence:` < 0.6 and older than 3 months.

**Interpretation:** You promoted something you weren't fully sure about, and you haven't done the work to resolve it.

**Action options:**
- Do the work to raise confidence
- Accept low confidence explicitly — add a "Known uncertainties" section making it clear
- Demote back to C1 if your confidence has actually dropped further

---

### Unresolved flags
Notes tagged `#contested` or `#needs-revision` older than 2 months.

**Interpretation:** A flag you didn't act on is worse than no flag — it's accumulated debt.

**Action options:**
- Resolve: revise, rewrite, or accept
- Demote back to C1 if the revision is substantial
- Remove the flag if it no longer applies

Do not let flags accumulate silently. They become noise that obscures new flags.

---

### Duplicate / near-duplicate detection
Notes with similar titles or strongly overlapping content.

**Interpretation:** You wrote two notes about the same thing, probably months apart, and forgot the earlier one existed.

**Action options:**
- Merge into one canonical note
- Redirect any links from the absorbed note to the survivor
- Do not keep both "just in case" — that defeats the point

---

### Cluster detection
Groups of 5+ notes sharing 2+ domain tags with no map note organizing them.

**Interpretation:** You've accumulated enough in a sub-area to deserve structure, but haven't created it.

**Action options:**
- Create a map note that surveys the cluster
- Decide the cluster doesn't warrant structure (some clusters are incidental)

---

## Cadence

- **Monthly** — minimum. Quarterly is tolerable but drift accumulates.
- **Less than quarterly** = system rot.

## The cardinal rule

**Never fix during lint. Only flag.**

The discipline of triage-then-act is what keeps lint from becoming a black hole. A 15-minute session that produces a prioritized flag list is sustainable. A 3-hour session where you try to fix everything is not, and will be skipped next month.

Separate sessions:
1. **Lint** (15 min) — report + triage
2. **Fix** (as needed, separate) — act on one flag at a time, at your own pace

## What never goes into lint

- Quality judgments about individual arguments
- Rewriting content
- Promotion decisions

Lint is structural, not epistemic. Structure reveals where attention is needed. Attention is a separate thing you give.
