# Retrieval

Three mechanisms. Total cost ≈ 15 min/week. Without them, C2 becomes a mausoleum.

## Why this matters

The point of the whole pipeline is retrieval and reuse, not storage. A note you can't find when you need it, or whose content has quietly decayed in your memory, is equivalent to a note that doesn't exist — with the added cost that you thought it was there.

Your own observation, from `Current_Mental_State.md`: concepts fade without use. Passive review is not enough. But heavy review is unsustainable. These three mechanisms are the minimum to prevent silent decay while staying light enough that you'll actually do them.

---

## 1. Neighborhood reactivation (continuous, free)

**When:** Whenever you open any C2 note while working.

**What:** Glance at the wikilinks and backlinks panel. Notice what's linked to the current note. If anything feels stale — you can't immediately recall its content — mark it mentally or with a `#needs-revision` tag.

**Cost:** Zero extra time. You're already opening notes while working.

**Why it works:** Relational cognition (which, per your mental-state doc, describes you) benefits from context reactivation. Seeing a related note title is enough to refresh the trace — or to reveal that it hasn't been refreshed in a long time.

Obsidian's built-in backlinks pane supports this natively.

---

## 2. Weekly surface (5 min, pick a day)

**When:** Once a week. Pick a consistent slot (Friday afternoon, Sunday evening — whatever you'll actually do).

**What:**
1. Pick 3 random notes from `03_Shelf/`, weighted toward the oldest `updated:` field.
2. Read **titles and one-sentence summaries only.**
3. For each, decide in 30 seconds: **solid / revisit / stale.**
4. Action:
   - *Solid* → touch the `updated:` field (optional but useful for weighting)
   - *Revisit* → tag `#needs-revision`
   - *Stale* → tag `#needs-revision` and add a one-line note on why

Do **not** re-study the note. Recognition alone reactivates memory traces. Studying is a separate decision.

**Cost:** 5 minutes.

**Template:** `_Templates/Weekly_review.md`

---

## 3. Monthly lint (10–15 min, first of month)

**When:** Once a month. First Monday or wherever fits.

**What:**
1. Invoke Lint Auditor (see `_System/03_Characters.md`) with current vault state.
2. Receive structured report.
3. Triage — mark items for action, do not fix in the same session.

**Triage targets:**
- Orphans → wire them or demote to CR
- Stale solids → schedule revisit or flag `#contested`
- Low-coverage maps → decide: grow, archive, or refactor
- Unresolved flags older than 2 months → force a decision
- Clusters without maps → create a map or explicitly decline

**Cost:** 10–15 minutes for the sweep. Fixes happen in separate, as-needed sessions.

**Template:** `_Templates/Monthly_lint.md`

---

## The one rule

**Never fix during a review session.** Reviews produce to-do lists. Fixes are a separate mode. Mixing them turns monthly lint into a 3-hour rabbit hole that you'll skip next time.

## If you skip these

You will skip the weekly sometimes. That's tolerable — missing one week doesn't break anything.

Skipping monthly lint consistently for 3+ months is a system-rot signal. At that point, C2 has accumulated drift: orphans, stale solids, unresolved flags. Catching up requires a longer session and it feels worse, so you skip again. This is the failure spiral.

If you find yourself skipping lint, that's a stronger signal than missing a single review: you're not using C2 enough to notice the decay. Either reduce the system's scope or accept that it's becoming a write-only archive and adjust expectations accordingly.
