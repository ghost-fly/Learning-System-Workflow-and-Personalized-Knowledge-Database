# Taxonomy

Three orthogonal tag dimensions. Flat within each. Designed to grow, but deliberately.

Also mirror these in YAML frontmatter — frontmatter is machine-readable and survives tag drift.

## Dimension 1: Domain (1–N tags)

Where does this knowledge live? A note can belong to multiple domains — expected, not exceptional.

**Starter list (extend deliberately, not reactively):**
- `#finance`
- `#stats`
- `#probability`
- `#math`
- `#programming`
- `#philosophy`
- `#epistemology`
- `#logic`
- `#economics`
- `#accounting`
- `#real-estate`
- `#psychology`

**Rules:**
- Add a new domain tag only when you have 3+ notes that genuinely belong to it.
- Domains are **flat**. Do not create `#finance/valuation/DCF`. Use wikilinks instead.
- Multi-domain tagging is expected. A Bayesian inference note might be `#stats #probability #epistemology`.

## Dimension 2: Type (exactly 1 tag)

What kind of knowledge-object is this? Drives how the note is processed and reviewed.

**Fixed list — do not add without deliberate decision:**

| Tag | Meaning | Stress test required for C2? |
|---|---|---|
| `#concept` | An idea, entity, or phenomenon | No |
| `#formula` | A mathematical expression or equation | **Yes** |
| `#principle` | A general rule or foundational statement | No |
| `#heuristic` | A rule of thumb; approximate, pragmatic | No |
| `#distinction` | A contrast or disambiguation between concepts | No |
| `#method` | A procedure or algorithm | **Yes** |
| `#fact` | A discrete factual claim | No |
| `#map` | An organizing note that tracks sub-concepts | No |

## Dimension 3: Status (exactly 1 tag)

Where is this in the pipeline? Update when you move files.

| Tag | Expected folder | Meaning |
|---|---|---|
| `#c0-capture` | `00_Capture/` | Just captured, awaiting routing |
| `#c0-park` | `00_Capture/` | Parked, has 90-day expiry |
| `#c1-draft` | `02_FirstForm/` | Being formed |
| `#c2-solid` | `03_Shelf/` | Passed the gate |
| `#needs-revision` | `03_Shelf/` | Flagged by lint or self-review |
| `#contested` | anywhere | High uncertainty, open questions |

`#contested` can coexist with other status tags — a note can be `#c2-solid #contested` meaning "shelved but I'm not fully settled on it."

## Discipline

- Every note has: **1 status + 1 type + N domain** tags.
- Before inventing a new tag, ask: "Is this information better carried by a link?"
- Do **not** create sub-domain hierarchies.
- Do **not** retrofit tags onto old notes reactively. Batch taxonomy work.

## Refactoring cadence

Every ~3 months, review the tag list. Flag:
- Domains with < 5 notes that could be merged or retired
- Tags used once or twice (probably noise)
- Concepts that cluster naturally and might deserve a new tag or map note

Do this as a separate session, not during normal work.
