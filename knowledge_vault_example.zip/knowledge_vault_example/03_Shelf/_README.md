# C2 — Shelf

Solid, linked, passed-the-gate knowledge. The network.

## Admission criteria

A note is admitted to the shelf only when all of these hold:

1. All 7 protocol questions are answered cleanly
2. **Q6 is concrete** — a real or specific hypothetical use case, not abstract gesturing
3. Stress test passed if `#formula` or `#method`
4. Devil's Advocate scrutiny complete; issues addressed or explicitly flagged
5. Linked to at least one other note (usually more)
6. Tags valid: 1 status + 1 type + ≥ 1 domain
7. `promoted:` date in frontmatter

## What this means

Everything here should be something you'd defend under questioning. Not "finished" in some final sense — knowledge evolves — but solid enough that you'd stake a claim on it without needing to re-read the source first.

## Revision is allowed

C2 notes are not frozen. If scrutiny later reveals a flaw:

- Minor fix → edit in place, update `updated:` field
- Substantial rework → tag `#needs-revision`, or demote back to C1 if the structure changes significantly

Demotion is not failure. A note that moves back to C1 for serious rework is the system working correctly.

## What C2 is not

- Not a personal Wikipedia. You are not trying to cover a domain; you are trying to build the subset of a domain you actually use.
- Not permanent. Archive unused branches rather than letting them rot.
- Not write-only. The retrieval mechanisms (`_System/04_Retrieval.md`) exist because silent decay is the default failure mode of shelved knowledge.
