<!-- next_id: N0036 -->

# Vault Index

---

## Programming

- N0001 [[Python Learning]] — map: core Python fundamentals pipeline (0/3 children)
- N0002 [[Core Fundamentals]] — `#c1-draft` map: syntax, variables, I/O, operators (0/7 children)
- N0024 [[Data Types]] — `#c0-capture` map: int/float/str/bool/None + collections + conversion + mutability + dynamic typing (0/11 children)
- N0003 [[Flow Control]] — `#c0-capture` conditionals, loops, loop control
- N0005 [[Functions & Modules]] — `#c0-capture` defining functions, built-ins, importing
- N0006 [[File Handling]] — `#c0-capture` reading/writing files, context managers
- N0007 [[Error Handling]] — `#c0-capture` try/except, common exceptions
- N0008 [[Python Syntax Rules]] — `#c0-capture` prescriptive reference of 6 core syntax rules
- N0009 [[Variables]] — `#c0-capture` names, objects, assignment semantics, namespaces
- N0010 [[Basic Input & Output]] — `#c0-capture` print(), input()
- N0011 [[Operators]] — `#c0-capture` arithmetic, comparison, logical, assignment, identity, membership
- N0012 [[Syntax in Human Languages]] — `#c0-capture` grammar rules in natural language; contrast to programming syntax
- N0016 [[Syntax in Programming Languages]] — `#c0-capture` what syntax is, syntax vs linter, why it exists
- N0017 [[Compiler & Interpreter]] — `#c0-capture` how source code becomes machine code; open questions remain
- N0018 [[Machine Code vs Source Code]] — `#c0-capture` CPU-readable vs human-readable code
- N0019 [[Code & Code Block]] — `#c0-capture` general code vs Python-specific indentation-defined blocks
- N0020 [[Colons in Python]] — `#c0-capture` 4 roles of colons: block header, slicing, dict key-value, type hints
- N0021 [[Brackets in Python]] — `#c0-capture` round (), square [], curly {} — meaning vs line continuation
- N0023 [[Assignment Operators]] — `#c0-capture` `=` as name-binding command vs math's `=`; contrast with `==`
- N0025 [[Integers & Floats]] — `#c0-capture` numeric types, operations, precision
- N0026 [[Strings]] — `#c0-capture` `str`, quotes, concatenation, indexing
- N0027 [[Booleans & None]] — `#c0-capture` `True`/`False`, `None`, truthiness
- N0028 [[Type Conversion]] — `#c0-capture` int(), float(), str(), bool() — casting and edge cases
- N0029 [[Mutability]] — `#c0-capture` mutable vs immutable types, why it matters
- N0030 [[Dynamic Typing]] — `#c0-capture` types live on values, not on variable names
- N0031 [[Lists]] — `#c0-capture` ordered, indexed, mutable collection
- N0032 [[Tuples]] — `#c0-capture` ordered, indexed, immutable collection
- N0033 [[Dictionaries]] — `#c0-capture` key-value mapping
- N0034 [[Sets]] — `#c0-capture` unordered, unique elements
- N0035 [[Literals]] — `#c0-capture` syntactic forms for writing each data type directly in code