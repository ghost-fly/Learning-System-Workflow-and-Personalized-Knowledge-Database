# Session Log — YYYY-MM-DD (Session N)

## Characters active
<!-- Which of the four roles was used this session -->

## Notes touched
<!-- List files created, updated, or promoted. Format: action | file | brief reason -->

## Decisions made
<!-- Routing calls, promotion/demotion outcomes, triage results -->

## Foundations flagged
<!-- Any prerequisites that were missing when INGEST was attempted -->

## Contradictions flagged
<!-- Any conflicts between new content and existing notes -->

## Open threads
<!-- Anything unresolved — a concept still in formation, a note awaiting Devil's Advocate, a pending triage -->

## Next action
<!-- The single clearest thing to do when we resume -->
