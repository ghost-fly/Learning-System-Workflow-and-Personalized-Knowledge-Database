# _LLM_Log

Session narrative logs. One file per session.

The LLM writes to this folder at the end of every working session. The purpose is continuity — the next session reads the most recent entry here to restore context without the human owner having to re-explain.

## What each log entry contains

- **Date and session number**
- **Character(s) used** — which of the four roles was active
- **Notes touched** — which files were created, updated, or promoted
- **Decisions made** — any routing decisions, promotion/demotion calls, or triage outcomes
- **Open threads** — anything unresolved that should be picked up next session
- **Next action** — the clearest single thing to do when we resume

## Naming convention

```
YYYY-MM-DD_session-N.md
```

If multiple sessions happen in a day, increment N. Otherwise N=1.

## Rules

- The LLM writes this, not the human owner.
- The human owner can annotate entries but should not rewrite them.
- Do not delete old entries — they are the audit trail.
- Read the most recent file at the start of every session.
