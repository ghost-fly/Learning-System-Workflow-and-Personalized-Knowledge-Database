# Knowledge Pipeline Vault — v0.1

A personal knowledge management system built around a capture → formation → shelving pipeline, with explicit promotion gates, retrieval mechanisms, and maintenance routines.

## What this is

An Obsidian-compatible vault pre-configured with:
- Four containers (C0, CR, C1, C2) organized as folders
- A 7-question promotion protocol
- A lean taxonomy: Domain × Type × Status tags
- Four LLM characters for different stages of work
- Weekly and monthly review templates
- A starter example demonstrating the pipeline's recursion behavior

## Install

1. Open Obsidian
2. Menu → **Open folder as vault** → select this folder
3. Read `_System/00_Overview.md` first (≈ 3 min)
4. Skim the other `_System/` files for reference
5. When ready, process the example in `00_Capture/Example_learn_stats.md`

No plugins required. Works on vanilla Obsidian.

## Principles

- **You are the judge; the LLM is the assistant.** The LLM never decides what survives.
- **Atomic notes where possible, map notes where not.** Granularity is discovered, not assumed.
- **Promotion is earned.** Notes stay in C1 until they pass the full gate.
- **Retrieval matters more than capture.** Unused C2 decays. The review mechanisms exist to fight this.
- **File-over-app.** Plain markdown, YAML frontmatter, wikilinks. Portable forever.

## This is v0.1

Expect to redesign something within the first week of real use. Systems designed in the abstract always have friction points invisible until contact with use. Treat this as a working draft, not a finished product.

## Table of contents

- `_System/00_Overview.md` — the whole architecture on one page
- `_System/01_Protocol.md` — the 7 questions in detail
- `_System/02_Taxonomy.md` — tag reference
- `_System/03_Characters.md` — LLM role invocations
- `_System/04_Retrieval.md` — review mechanisms
- `_System/05_Lint.md` — maintenance operations
- `_Templates/` — templates for each note type and review
- `00_Capture/Example_learn_stats.md` — demo of the pipeline recursion
