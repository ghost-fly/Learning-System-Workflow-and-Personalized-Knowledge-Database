<%*
const indexPath = "index.md";
const indexContent = await app.vault.adapter.read(indexPath);
const match = indexContent.match(/<!-- next_id: N(\d+) -->/);
const currentNum = parseInt(match[1]);
const assignedId = "N" + String(currentNum).padStart(4, '0');
const nextId = "N" + String(currentNum + 1).padStart(4, '0');
await app.vault.adapter.write(
  indexPath,
  indexContent.replace(`<!-- next_id: ${assignedId} -->`, `<!-- next_id: ${nextId} -->`)
);
_%>---
id: <% assignedId %>
aliases: ["<% assignedId %>"]
status: c0-capture
captured: <% tp.date.now("YYYY-MM-DD") %>
source:
triggered_by:
route:
park_expires:
updated:
---

# <% tp.file.title %>

## Triggered by

<!-- If this note came up while working on another, wikilink it here. Leave blank for root-level captures. Backlinks will render the trigger chain automatically. -->
[[ ]]

## Raw content

<!-- Whatever you captured — paste, write, link. Messy is fine. -->


## Why I captured this

<!-- One line. If you can't justify in a line, it's probably discard. -->


## Next action

<!-- discard / park until [date] / move to CR / process as atomic / process as map candidate -->
