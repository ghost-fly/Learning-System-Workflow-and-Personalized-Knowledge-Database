---
id: N----
aliases: ["N----"]
status: c2-solid
type: map
domain: []
created: YYYY-MM-DD
updated: YYYY-MM-DD
promoted: YYYY-MM-DD
coverage: X/Y
triggered_by:
---

# [Domain or Concept Map]

## Triggered by

<!-- Wikilink to the note(s) that triggered this one. Historical origin — preserved through promotion. -->
[[ ]]

## Scope


## Structure

<!-- Organized list of children. Use sub-headings for sub-areas if natural. -->

### [Sub-area 1]
- [[Atomized concept A]]
- [[Atomized concept B]]
- [ ] [[Not yet atomized]] — `#c1-draft` or `#c0-capture`

### [Sub-area 2]
- ...


## Prerequisite structure


## Boundaries with adjacent domains


## Known gaps

<!-- What this map deliberately doesn't cover, and why. -->


## Links
- [[...]]
