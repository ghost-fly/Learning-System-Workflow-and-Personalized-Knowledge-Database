---
id: N----
aliases: ["N----"]
status: c1-draft
type: map
domain: []
created: YYYY-MM-DD
updated: YYYY-MM-DD
coverage: 0/0    # atomized children / total listed
triggered_by:
---

# [Domain or Concept Map]

## Triggered by

<!-- Wikilink to the note(s) that triggered this one. Leave blank for root-level maps. -->
[[ ]]

## Scope

<!-- What this map covers. What it deliberately does NOT cover. -->


## Why the protocol failed at this scale

<!-- Which questions couldn't be answered cleanly, and why decomposition was needed. This is valuable — don't skip. -->


## Decomposition

<!-- Sub-concepts spawned back to C0 as individual items. Update status as they progress through the pipeline. -->

- [ ] [[Sub-concept 1]] — `#c0-capture`
- [ ] [[Sub-concept 2]] — `#c0-capture`
- [ ] ...


## Prerequisite structure

<!-- What depends on what. Use indentation or arrows. -->


## Boundaries with adjacent domains

<!-- Q2 at the map level: what's next to this that isn't inside it? -->


## Open questions at the map level


## Links
- [[...]]
