---
id: N----
aliases: ["N----"]
status: c1-draft
type: concept      # concept / formula / principle / heuristic / distinction / method / fact
domain: []         # e.g. [finance, stats]
created: YYYY-MM-DD
updated: YYYY-MM-DD
confidence: 0.0    # 0.0 – 1.0
source:
triggered_by:
---

# [Concept]

## Triggered by

<!-- Wikilink to the note(s) that triggered this one. Leave blank for root-level concepts. -->
[[ ]]

## 1. One-sentence definition (no jargon)


## 2. What it connects / sits between


## 3. Why it exists (problem solved)


## 4. Edge cases / where it breaks


## 5. Easily confused with


## 6. Where I've used it / would use it

<!-- Hard gate for C2 promotion. Be concrete. -->


## 7. Confidence and what would change my mind


## Stress test (only if type is #formula or #method)

### Worked example from scratch


### Applied and verified


### When NOT to use it


## Open questions / gaps to fill before promotion


## Links
- [[...]]
