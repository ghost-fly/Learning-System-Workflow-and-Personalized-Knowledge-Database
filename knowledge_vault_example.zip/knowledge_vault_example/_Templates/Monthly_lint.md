---
type: review
scope: monthly
date: YYYY-MM-DD
---

# Monthly Lint — YYYY-MM-DD

Goal: 10–15 minutes. Report + triage only. **Do not fix in this session.**

## Lint Auditor report

<!-- Paste the LLM's structured output here. -->


## Triage

### Orphans
- [[...]] → wire / demote to CR / archive

### Stale solids
- [[...]] → recognition test: pass / fail → action

### Low-coverage maps
- [[...]] → grow / archive / refactor

### Unresolved flags
- [[...]] → resolve by [date]

### Duplicate candidates
- [[A]] + [[B]] → merge into [[canonical]]

### Clusters without maps
- [tags] → create map / skip

## Actions queued for this month

<!-- Concrete fixes to tackle in separate sessions. One per line. -->

- [ ] ...
- [ ] ...
