---
type: review
scope: weekly
date: YYYY-MM-DD
---

# Weekly Review — YYYY-MM-DD

Goal: 5 minutes. Recognition, not study. Do not re-read notes.

## 3 notes surfaced

<!-- Pick 3 at random from `03_Shelf/`, weighted toward oldest `updated:` field. -->

1. [[Note 1]] — solid / revisit / stale
2. [[Note 2]] — solid / revisit / stale
3. [[Note 3]] — solid / revisit / stale

## Observations

<!-- One-line observations only. What did you notice? -->


## Flags added

<!-- Any `#needs-revision` tags added, with one-line reason. -->


## Next week

<!-- Only if something specific needs carrying over. Usually empty. -->
