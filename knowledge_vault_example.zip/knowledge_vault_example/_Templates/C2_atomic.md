---
id: N----
aliases: ["N----"]
status: c2-solid
type: concept
domain: []
created: YYYY-MM-DD
updated: YYYY-MM-DD
promoted: YYYY-MM-DD
confidence: 0.0
source:
triggered_by:
---

# [Concept]

## Triggered by

<!-- Wikilink to the note(s) that triggered this one. Historical origin — preserved through promotion. -->
[[ ]]

## 1. Definition


## 2. What it connects / sits between


## 3. Why it exists


## 4. Edge cases / where it breaks


## 5. Easily confused with


## 6. Use cases

<!-- Concrete, not abstract. Where you've actually applied it or a specific situation where you would. -->


## 7. Confidence and falsifiers

<!-- Current confidence. What observation or argument would change your view. -->


## Stress test (for #formula / #method)

### Worked example


### Applied and verified against source


### When NOT to use it


## Known uncertainties

<!-- Leave empty if none. If present, be explicit about what remains unresolved. -->


## Links
- [[...]]
