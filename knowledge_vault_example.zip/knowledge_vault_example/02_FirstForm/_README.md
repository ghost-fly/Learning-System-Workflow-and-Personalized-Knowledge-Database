# C1 — First-Form Notes

Drafts. Where formation happens.

## Two shapes

- **Atomic draft** — concept-sized, being refined toward promotion. Use `_Templates/C1_atomic.md`.
- **Map draft** — too large to atomize, decomposes into sub-concepts that go back to C0. Use `_Templates/C1_map.md`.

Granularity is discovered, not assumed. If the protocol fails Q1 (can't define in one plain sentence without hedging), the note is a map, not an atomic concept.

## No time pressure

A note can live in C1 for weeks or months. Promotion is earned by passing the full gate, not by waiting long enough.

If a note has been in C1 for 6+ months without progress, that's a signal worth investigating — either the concept is harder than you thought (fine, keep working), you've lost interest (fine, archive), or you're stuck on a specific question (fine, break it out).

## Promotion checklist

Before moving a note to `03_Shelf/`:

1. All 7 protocol questions answered cleanly
2. Stress test passed (if `#formula` or `#method`)
3. Devil's Advocate sweep complete; issues raised have been addressed or explicitly flagged
4. At least one wikilink to another note
5. Tags updated: status, type, domain(s)
6. `promoted:` date added to frontmatter
7. File moved to `03_Shelf/`
