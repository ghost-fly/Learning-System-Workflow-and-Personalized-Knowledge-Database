---
id: N0002
aliases: ["N0002"]
status: c1-draft
type: map
domain: [programming]
created: 2026-04-19
updated: 2026-04-22
coverage: 0/7
triggered_by: "[[Python Learning]]"
---

# Core Fundamentals

## Triggered by

[[Python Learning]]

## Scope

The foundational Python concepts a beginner learns first — the building blocks for writing any working Python program. Covers syntax, data primitives, I/O, operators, flow control, and functions.

## Why the protocol failed at this scale

"Core Fundamentals" is a category label, not a concept. Q1 cannot be answered — there is no single definition for a collection of six distinct topics. Each sub-topic below answers Q1 cleanly on its own.

## Decomposition

- [x] [[Python Syntax Rules]] — `#c0-capture`
- [x] [[Variables]] — `#c0-capture`
- [ ] [[Data Types]] — `#c0-capture` (map, 0/11 children)
- [ ] [[Basic Input & Output]] — `#c0-capture`
- [ ] [[Operators]] — `#c0-capture`
- [ ] [[Flow Control]] — `#c0-capture`
- [ ] [[Functions & Modules]] — `#c0-capture`

## Prerequisite structure

Python Syntax Rules → everything else
Variables → Data Types → Operators → Basic Input & Output
Variables → Data Types → Flow Control → Functions & Modules

## Boundaries with adjacent domains

- Stays within `#programming` — no crossover yet
- Data Types will connect to `#stats` later (numeric types, precision)

## Open questions at the map level

- (none currently open)

## Links
- [[Python Learning]]