---
id: N0001
aliases: ["N0001"]
status: c1-draft
type: map
domain: [programming]
created: 2026-04-18
updated: 2026-04-22
coverage: 0/3
triggered_by:
---

# Python Learning

## Triggered by

<!-- Root-level map — no trigger. -->
[[ ]]

## Scope

Python is a high-level, general-purpose, interpreted programming language designed for readability and beginner-friendliness. Created by Guido van Rossum, first released in 1991. Used for scripting, data analysis, automation, web development, and building small tools.

This map covers core Python fundamentals needed to reach practical competency: writing scripts, working with data, and building small programs. It does NOT cover advanced topics (OOP depth, async, decorators, packaging, frameworks).

## Why the protocol failed at this scale

Q1 fails — "Python" as a whole cannot be defined in one atomic sentence that is meaningfully distinguishable from other languages. It is a language containing many distinct, independently learnable concepts. Each sub-topic below can pass Q1 cleanly on its own.

## Decomposition

- [ ] [[Core Fundamentals]] — `#c1-draft` (map, 0/7 children)
- [ ] [[File Handling]] — `#c0-capture`
- [ ] [[Error Handling]] — `#c0-capture`

## Prerequisite structure

Core Fundamentals → everything else

## Boundaries with adjacent domains

- `#programming` overlaps with `#data-analytics` once you reach pandas/numpy (out of scope here)
- File Handling borders `#data-analytics` (CSV/JSON processing)

## Open questions at the map level

- Does "Core Fundamentals" atomize cleanly or does it itself become a map?
- Where does OOP fit — out of scope for now, flag when it comes up

## Links