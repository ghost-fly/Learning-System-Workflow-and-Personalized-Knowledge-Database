# Reviews

Weekly and monthly review logs live here.

## Filename convention

- Weekly: `YYYY-MM-DD_weekly.md` (date = day of review)
- Monthly: `YYYY-MM-01_monthly.md` (always use the 1st, regardless of when you actually did it)

## What goes in the review note

The review template records **only** the triage output:
- Which notes were surfaced / flagged
- What decisions were made
- Actions queued for follow-up

The actual revisions and fixes happen **in the flagged notes themselves**, in separate sessions. Reviews produce to-do lists; they do not execute them.

## What does NOT go here

- Revisions to individual notes (those belong in the notes)
- Deep reflections on the system (those belong in a separate meta-note or at the top of `_System/`)
- Journal entries

Keep this folder narrow: it's audit trail for the review mechanism, nothing more.

## Retention

Reviews older than 12 months can be archived or deleted. They have no ongoing value once their actions are resolved.
