# CR — References

Durable library of sources. This is **not** every article you've read.

## What goes here

Only sources that meet one of these:
- You actually used it in a C1 or C2 note
- You have high confidence you'll reuse it

## What each entry contains

- Citation (author, title, year, venue)
- Stable link or DOI
- Only the excerpts you used (not the full text)
- One-line "why this matters"

## The 12-word test

If you can't justify an entry's presence in 12 words or fewer, it doesn't belong here. Ambiguous entries accumulate into a hoarding bin that duplicates what Instapaper/Readwise already fail at.

## Organization

Flat folder, no sub-folders. Use the same domain tags as the rest of the vault. Lint will flag unused entries during monthly sweeps.

## Filename convention

`[YYYY]_[AuthorLastName]_[ShortTitle].md`

Examples:
- `2019_Kahneman_ThinkingFastSlow.md`
- `2008_Silver_538_PrimariesModel.md`
